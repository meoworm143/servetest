<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ZoneManagement\\Providers\\ZoneManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ZoneManagement\\Providers\\ZoneManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);