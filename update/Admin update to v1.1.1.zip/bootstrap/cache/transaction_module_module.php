<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TransactionModule\\Providers\\TransactionModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TransactionModule\\Providers\\TransactionModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);