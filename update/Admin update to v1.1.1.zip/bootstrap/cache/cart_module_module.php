<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CartModule\\Providers\\CartModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CartModule\\Providers\\CartModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);