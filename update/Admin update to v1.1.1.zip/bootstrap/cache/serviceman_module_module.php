<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ServicemanModule\\Providers\\ServicemanModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ServicemanModule\\Providers\\ServicemanModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);