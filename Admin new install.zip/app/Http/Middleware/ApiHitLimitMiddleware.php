<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;

class ApiHitLimitMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @param string $attempt_type
     * @param int $hit_count
     * @return JsonResponse
     */
    public function handle(Request $request, Closure $next, string $attempt_type = "normal", int $hit_count = 10)
    {
        if ($request->user()) {
            $cache_id = $request->user()->id;
        } else {
            $cache_id = $request->ip();
        }

        if(!RateLimiter::attempt($attempt_type . $cache_id, $perMinute = $hit_count, function () {})){
            return response()->json(response_formatter(TOO_MANY_ATTEMPT_403), 403);
        }

        return $next($request);
    }
}
