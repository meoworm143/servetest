<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CategoryManagement\\Providers\\CategoryManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CategoryManagement\\Providers\\CategoryManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);