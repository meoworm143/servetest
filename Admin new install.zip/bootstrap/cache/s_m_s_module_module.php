<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SMSModule\\Providers\\SMSModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SMSModule\\Providers\\SMSModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);