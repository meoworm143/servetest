<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ReviewModule\\Providers\\ReviewModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ReviewModule\\Providers\\ReviewModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);